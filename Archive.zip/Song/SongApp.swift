//
//  SongApp.swift
//  Song
//
//  Created by Mohammad Tofik Sheikh on 14/08/24.
//

import SwiftUI

@main
struct SongApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
